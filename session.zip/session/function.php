<?php
    $conn = mysqli_connect('localhost','admin','=@!#254tecmint','session');
    global $conn;

function insert(){

    global $conn;
    
    $userName = $_POST['name_us'];
    $userEmail = $_POST['email_us'];
    $userPass = $_POST['password_us'];
    
    $sql = "INSERT INTO login_info(user_name,email_name,password) VALUES('$userName','$userEmail','$userPass')";
    $row =mysqli_query($conn,$sql);

    echo "success !";
}


function availabel(){

    global $conn;

    $name = mysqli_real_escape_string($conn,$_POST['name_check']); // between the values reading (, / ' ") this type of symbol as string
    $query = "SELECT * FROM login_info WHERE user_name = '".$name."' ";
    $result = mysqli_query($conn,$query);
    echo mysqli_num_rows($result);
}

function loginValueCheck(){
    
    global $conn;

    $log_name =mysqli_real_escape_string($conn,$_POST['name']); // between the values reading (, / ' ") this type of symbol as string.
    $log_pwd = mysqli_real_escape_string($conn,$_POST['pwd']);

    $nam_query = "SELECT * FROM login_info WHERE user_name = '".$log_name."'";
    $result = mysqli_query($conn,$nam_query);
    $usercnt =  mysqli_num_rows($result);
    $response = array();
    
    if($usercnt > 0){
        $pss_query = "SELECT * FROM login_info WHERE user_name = '".$log_name."' AND password = '".$log_pwd."'";
        $pa_result = mysqli_query($conn,$pss_query);
        $passcnt =  mysqli_num_rows($pa_result);

        if($passcnt > 0){
            
            session_start();
            $_SESSION['username'] = $log_name;
            $_SESSION['userpwd']= $log_pwd;
            
            $response['type']="login";
            $response['message']="Login Successfully";

        }else{
            $response['type']="password";
            $response['message']=" *Password is wrong !";
        }
    }else{
        $response['type']="username";  
        $response['message']=" *Username is not exist !";
    }
    echo json_encode($response);

}

?>