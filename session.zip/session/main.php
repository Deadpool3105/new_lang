<?php
    include 'function.php';
    
    if ($_POST['action'] == "log_info") {
        insert();
    }
    elseif (($_POST['action'] == "availablity")) {
        availabel();
    }
     elseif(($_POST['action'] == 'login_checked')){
        loginValueCheck();
    }
?>