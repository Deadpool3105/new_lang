<?php

session_start();
// if (!isset($_SESSION['logged']) || isset($_SESSION['logged'])!=true ) {
//     header("location: login.php");
//     exit;
// }
// echo "Your username is : ".$_SESSION['username'] ;
// echo"<br><br> Password is : ".$_SESSION['userpwd'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.2.0/dist/css/bootstrap.min.css">
    <title>Welcome - <?php echo $_SESSION['username']?></title>
</head>
<body>
    <h4>Your username is : <?php echo $_SESSION['username'] ?></h4>
    <h4>Password is : <?php echo $_SESSION['userpwd'] ?></h4>

    <button type="button" class="btn btn-danger" id="backbutton">logout</button>

</body>
<script src="data.js"></script>
</html>