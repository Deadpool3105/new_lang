$(document).ready(function () {
  $("#SignupForm").validate({
    rules: {
      name: {
        required: true,
      },
    },
    messages: {
      name: {
        required: "*Pleace enter user name!",
      },
    },
    submitHandler: function () {
      var usname = $("#user_name").val();
      var mail = $("#user_email").val();
      var pass = $("#user_password").val();
      var action = "log_info";
      $.ajax({
        url: "main.php",
        method: "POST",
        data: {
          action: action,
          name_us: usname,
          email_us: mail,
          password_us: pass,
        },
        success: function (data) {
          alert(data);
        },
      });
    },
  });

  $("#user_name").keyup(function () {
    var usName = $(this).val().trim();
    var action = "availablity";
    $.ajax({
      url: "main.php",
      method: "POST",
      data: { name_check: usName, action: action },
      success: function (data) {
        if (data > 0) {
          $("#s1").css("color", "#bd1313");
          $("#submitbutn").attr("disabled", true);
          $("#check").html("Not available").css("color", "#bd1313");
        } else {
          if (usName == "") {
            $("#s1").css("color", "#bd1313");
            $("#submitbutn").attr("disabled", true);
            $("#check").html("Mandatory").css("color", "#bd1313");
          } else {
            $("#check").html("");
            $("#s1").css("color", "green");
            $("#submitbutn").attr("disabled", false);
          }
        }
      },
    });
  });

  $("#SigninForm").submit(function (e) {
    e.preventDefault();
    var ln_name = $("#login_name").val().trim();
    var ln_pwd = $("#login_password").val().trim();
    var action = "login_checked";
    $.ajax({
      url: "main.php",
      method: "POST",
      dataType: "json",
      data: { name: ln_name, pwd: ln_pwd, action: action },
      success: function (data) {
        if (data.type == "username") {
          $("#inncLogin").html("");$(document).ready(function () {
            $("#SignupForm").validate({
              rules: {
                name: {
                  required: true,
                },
              },
              messages: {
                name: {
                  required: "*Pleace enter user name!",
                },
              },
              submitHandler: function () {
                var usname = $("#user_name").val();
                var mail = $("#user_email").val();
                var pass = $("#user_password").val();
                var action = "log_info";
                $.ajax({
                  url: "main.php",
                  method: "POST",
                  data: {
                    action: action,
                    name_us: usname,
                    email_us: mail,
                    password_us: pass,
                  },
                  success: function (data) {
                    alert(data);
                  },
                });
              },
            });
          
            $("#user_name").keyup(function () {
              var usName = $(this).val().trim();
              var action = "availablity";
              $.ajax({
                url: "main.php",
                method: "POST",
                data: { name_check: usName, action: action },
                success: function (data) {
                  if (data > 0) {
                    $("#s1").css("color", "#bd1313");
                    $("#submitbutn").attr("disabled", true);
                    $("#check").html("Not available").css("color", "#bd1313");
                  } else {
                    if (usName == "") {
                      $("#s1").css("color", "#bd1313");
                      $("#submitbutn").attr("disabled", true);
                      $("#check").html("Mandatory").css("color", "#bd1313");
                    } else {
                      $("#check").html("");
                      $("#s1").css("color", "green");
                      $("#submitbutn").attr("disabled", false);
                    }
                  }
                },
              });
            });
          
            $("#SigninForm").submit(function (e) {
              e.preventDefault();
              var ln_name = $("#login_name").val().trim();
              var ln_pwd = $("#login_password").val().trim();
              var action = "login_checked";
              $.ajax({
                url: "main.php",
                method: "POST",
                dataType: "json",
                data: { name: ln_name, pwd: ln_pwd, action: action },
                success: function (data) {
                  if (data.type == "username") {
                    $("#inncLogin").html("");
                    $("#inncorectpwd").html("");
                    $("#inncorectname").html(data.message).css("color", "red");
                  } else {
                    if (data.type == "password") {
                      $("#inncorectname").html("");
                      $("#inncLogin").html("");
                      $("#inncorectpwd").html(data.message).css("color", "red");
                    } else {
                      $("#inncorectpwd").html("");
                      $("#inncorectname").html("");
                      $("#inncLogin").html(data.message).css("color", "green");
                      window.location.href = "display.php";
                    }
                  }
                },
              });
            });
          
            $("#backbutton").click(function () {
              $.ajax({
                url: "logout.php",
                method: "POST",
                success: function (data) {
                  alert(data);
                  window.location.href = "login.php";
                },
              });
            });
          });
          
          $("#inncorectpwd").html("");
          $("#inncorectname").html(data.message).css("color", "red");
        } else {
          if (data.type == "password") {
            $("#inncorectname").html("");
            $("#inncLogin").html("");
            $("#inncorectpwd").html(data.message).css("color", "red");
          } else {
            $("#inncorectpwd").html("");
            $("#inncorectname").html("");
            $("#inncLogin").html(data.message).css("color", "green");
            window.location.href = "display.php";
          }
        }
      },
    });
  });

  $("#backbutton").click(function () {
    $.ajax({
      url: "logout.php",
      method: "POST",
      success: function (data) {
        alert(data);
        window.location.href = "login.php";
      },
    });
  });
});
