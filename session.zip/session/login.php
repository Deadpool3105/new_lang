<html>
<head>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"></script>
    <title>Log_In</title>
    <style>
        .error{
            color:#9b0824;
        }
        .img-fluid{
            width:90%;
        } 
        .ligfo{
            background:lightblue;
            border: 2px solid darkgrey;
            border-radius: 11px;
            height: fit-content;
            padding: 18px;
        }
    </style>
</head>
<body>
<div class="container">
        <div class=" row justify-content-center" style="margin-top: 8%;">
            <div class="col-7">
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.webp" class="img-fluid">
            </div>
            <div class="col-5">
                <h1  class="text-center mb-4">Log In</h1>
                <form id="SigninForm" class="ligfo">
                    <div class="form-group">
                        <div class="d-flex justify-content-between">
                            <label for="userName" class="mb-2 h5">User Name :</label>
                            <a href="login.php">
                                <button type="button" class="btn" style="margin-top: -7px; height:29px;">
                                    <i class="fa fa-close"></i>
                                </button>
                            </a>
                        </div>
                        <div class="">
                            <input type="text" class="form-control mb-3" name="username" id="login_name" placeholder="Enter your username...">
                        </div>
                        <span id="inncorectname"></span>
                    </div>
                    <div class="form-group">
                        <label for="userPassword" class="mb-2 h5">Password :</label>
                        <div class="">
                            <input type="password" class="form-control mb-3" name="userpwd" id="login_password" placeholder="Enter currect password...">
                        </div>
                        <span id="inncorectpwd"></span>
                    </div>
                    <div class="text-center mt-4">
                        <button type="submit" id="submitlog" name="loggedin"class="btn btn-info">
                               <!-- <a href="display.php"> -->
                               login
                               <!-- </a> -->
                        </button>
                    </div>
                    <span id="inncLogin"></span>
                </form>
             </div>
        </div>
    </div>
</body>
<script src="data.js" type="text/javascript"></script>
</html>