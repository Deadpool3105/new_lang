<html>
<head>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"></script>
    <title>Sign_Up</title>
    <style>
        .error{
            color:#9b0824;
        }
        .img-fluid{
            margin-top:-55px;
        } 
        .sigfom{
            background:lightblue;
            border: 2px solid darkgrey;
            height: 78%;
            border-radius: 11px;
            padding: 18px;
        }
        .loin{
            margin-top: -16px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class=" row justify-content-center" style="margin-top: 8%;">
            <div class="col-4">
                <h1 class="text-center mb-3">Sign Up</h1>
                <form id="SignupForm" class="sigfom">    
                    <div class="form-group">
                        <div style="display: flex;justify-content: space-between;">
                            <label for="userName" class="mb-2 h6" >
                                <span style="color: #bd1313;" id="s1">*</span>
                                 User Name :
                            </label>
                            <span id="check"></span>
                        </div>
                        <input type="text" class="form-control mb-3" name="username" id="user_name" placeholder="Enter user name...">
                    </div>
                    <div class="form-group">
                        <label for="userEmail" class="mb-2 h6">
                            <span style="color: #bd1313;">*</span>
                             Email :
                        </label>
                        <input type="mail" class="form-control mb-3" name="useremail" id="user_email" placeholder="Enter vaild email...">
                    </div> 
                    <div class="form-group">
                        <label for="userPassword" class="mb-2 h6">
                            <span style="color: #bd1313;">*</span> 
                            Password :
                        </label>
                            <input type="password" class="form-control mb-3" name="userpwd" id="user_password" placeholder="Enter strong password...">
                    </div>
                    <div class="text-center mt-4">
                            <button type="submit" id="submitbutn" class="btn btn-outline-success">Signup</button>
                    </div>
                    <div class="text-end loin">
                        <a href="login.php">login</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="data.js" type="text/javascript"></script>
</body>
</html>