$(document).ready(function () {

    /******************************** Create a DataTable ********************************/


    $("#myTable").DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "ajax": {
            url: "mysql.php",
            type: "POST",
            // data: { action: 'listEmployee' },
            dataType: "json"
        },
        "columnDefs": [
            { data: "id" },
            { data: "first_3" },
            { data: "last_3" },
            { data: "company_3" },
            { data: "mail_3" },
            { data: "Phone_3" },
        ],

        /******************************** Search in DataTable ********************************/

        initComplete: function () {
            var input = $('.dataTables_filter input').unbind(),
                self = this.api(),
                $searchButton = $('#myInputTextField').click(function () {
                    self.search(input.val()).draw();
                });
            $('.dataTables_filter').append($searchButton);
        }
    });

    /******************************** Update data in DataTable ********************************/

    $("#myTable").on('click', '.update', function () {
        var empId = $(this).attr("id");
        var action = 'getEmployee';
        $.ajax({
            url: 'mysql.php',
            method: "POST",
            data: { empId: empId, action: action },
            dataType: "json",
            success: function (data) {
                //console.log(data);
                $('#employeeModal').modal('show');
                $('#empId').val(data.id);
                $('#fname').val(data.first_3);
                $('#lname').val(data.last_3);
                $('#cname').val(data.company_3);
                $('#email').val(data.mail_3);
                $('#phone').val(data.Phone_3);
                $('#action').val('updateEmployee');
            }
        })
    });

    /******************************** Save updated data in DataTable ********************************/

    $(document).on('submit', '#employeeForm', function (e) {
        e.preventDefault();
        var formData = $(this).serialize();
        $('#save').attr('disabled', 'disabled');
        $.ajax({
            url: "mysql.php",
            method: "POST",
            data: formData,
            success: function (data) {
                // $('#employeeForm')[0].reset();
                $('#employeeModal').modal('hide');
                $('#save').attr('disabled', false);
                window.location.reload();
            }
        })
    });

    /******************************** Delete data into the DataTable ********************************/

    $("#myTable").on('click', '.delete', function () {
        var empId = $(this).attr("id");
        var action = "empDelete";
        if (confirm("Are you sure you want to delete this employee?")) {
            $.ajax({
                url: "mysql.php",
                method: "POST",
                data: { empId: empId, action: action },
                success: function (data) {
                    window.location.reload();
                }
            })
        } else {
            return false;
        }
    });
});
