$(document).ready(function () {
    $("#myTable").DataTable({
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        'ajax': {
            url: "mysql.php",
            type: "POST",
            dataType: "json",
        },
        'columns': [
            { data: "id"},
            { data: "first_3"}, 
            { data: "last_3"},
            { data: "company_3"}, 
            { data: "mail_3"}, 
            { data: "Phone_3"},
        ],
    });
});
