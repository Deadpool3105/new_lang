$(document).ready(function () {

    $("#signupForm").validate({
        rules: {
            first_3: {
                required: true,
                lettersonly: true,
                minlength: 2,
                maxlength: 20,
            },
            last_3: {
                required: true,
                lettersonly: true,
                minlength: 3,
                maxlength: 20,
            },
            company_3: {
                required: true,
                minlength: 5,
                maxlength: 20,
            },
            city_3: {
                required: true,
            },
            state_3: {
                required: true,
            },
            pin_3: {
                required: true,
                digits: true,
                minlength: 6,
                maxlength: 6
            },

            Phone_3: {
                required: true,
                digits: true,
                minlength: 10,
                maxlength: 10
            },

            mail_3: {
                required: true,
                email: true,
            }
        },
        messages: {
            first_3: {
                required: "*Enter your first name",
                lettersonly: "*please enter characters only",
            },
            last_3: {
                required: "*Enter your last name",
                lettersonly: "*please enter characters only",
            },
            city_3: { required: "*City name!" },
            state_3: "*State name!",
            company_3: "*Enter your company name!",
            pin_3: {
                required: "*Enter a pin code!",
                digits: "*Your PinCode must only in digits!",
            },

            Phone_3: {
                required: "*Enter phone number!",
                digits: "*Enter valid number!",
            },

            mail_3: {
                required: "*Enter email id!",
                email: "*Enter vslid mail id!",
            },
        },
        submitHandler: function (form) {
            //alert("test");
            $.ajax({
                url: "mysql.php",
                method: "POST",
                data: $(form).serialize(),
                success: function (data) {
                    alert("1 Record Added");
                }
            });
            // remove(data);
        }
    });

    
});