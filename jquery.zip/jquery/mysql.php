<?php

$connect = mysqli_connect('localhost','root','inextrix','test_demo'); // connect with database

/******************************** Delete data ********************************/

if($_POST['action'] == "empDelete"){
  $emp_id = $_POST['empId'];
  $sqlDelete = "DELETE FROM e_mart WHERE id = $emp_id";
  mysqli_query($connect,$sqlDelete);
  
}/******************************** Update data ********************************/
else if($_POST['action'] == "getEmployee"){
  $emp_id = $_POST['empId'];
  $sqlQuery = " SELECT * FROM e_mart WHERE id = $emp_id"; 
  $result = mysqli_query($connect,$sqlQuery);
  $row = mysqli_fetch_assoc($result);
  echo json_encode($row);
}
else if($_POST['action'] == 'updateEmployee'){
  $emp_id = $_POST['empId'];
  //	$sqlQuery = "UPDATE e_mart SET first_3 =".$_POST["fname"].", last_3 = ".$_POST["lname"].", company_3 = ".$_POST["cname"].", mail_3 = ".$_POST["emai>
	$sqlQuery = "UPDATE e_mart SET first_3 ='".$_POST["fname"]."', last_3 = '".$_POST["lname"]."', company_3 = '".$_POST["cname"]."', mail_3 = '".$_POST["email"]."' , Phone_3 = '".$_POST["phone"]."' WHERE id = '$emp_id'" ;
	
  $result = mysqli_query($connect, $sqlQuery);
}
/******************************** Add new data ********************************/

else if(isset($_POST["first_3"]) && isset($_POST['last_3']) && isset($_POST['company_3'])  && isset($_POST['add_line_1'])&& isset($_POST['add_line_2'])&& isset($_POST['city_3'])&& isset($_POST['state_3'])  && isset($_POST['pin_3']) && isset($_POST['Phone_3']) && isset($_POST['mail_3']))
// get values 
{
  $date = $_POST["date"];
  $pin = $_POST["pin_3"];
  $mail = $_POST["mail_3"];
  $city = $_POST["city_3"];
  $phone = $_POST["Phone_3"];
  $State = $_POST["state_3"];
  $lastname = $_POST["last_3"];
  $firstname = $_POST["first_3"];
  $address1 = $_POST["add_line_1"];
  $address2 = $_POST["add_line_2"];
  $companyname = $_POST["company_3"];
  
  $query = "INSERT INTO e_mart(date,first_3,last_3,company_3,add_line_1,add_line_2,city_3,state_3,pin_3,Phone_3,mail_3) VALUES('$date','$firstname','$lastname','$companyname','$address1','$address2','$city','$State ','$pin','$phone','$mail')";
  $result = mysqli_query($connect, $query);
  echo "1 Record Added!";
}  

/******************************** Search and select data in datatable ********************************/

else {
  $rowstart = $_POST['start'];
  $rowperpage = $_POST['length']; // Rows display per page
  $columnIndex = $_POST['order'][0]['column']+1; // Column index
  $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
  $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
  $searchValue = mysqli_real_escape_string($connect,$_POST['search']['value']); // Search value
  
  /* ******************************** */

  $sqlQuery .= " SELECT id, first_3, last_3,company_3,mail_3,Phone_3 FROM e_mart "; //apply select query.
  $searchQuery ='';
  if(!empty($searchValue)){ 
    $searchQuery .= "WHERE(first_3 LIKE '%".$searchValue."%' OR company_3 LIKE '%".$searchValue."%' OR Phone_3 LIKE '%".$searchValue."%')";
    $sqlQuery .= $searchQuery;
  }

  if(!empty($_POST["order"])){
    $sqlQuery .= 'ORDER BY '.$columnName.' '.$columnSortOrder.' ';
  } else {
    $sqlQuery .= "ORDER BY id desc ";
  }
  if($rowperpage != -1){
    $sqlQuery .= " LIMIT  $rowstart , $rowperpage ";
  }	

  /* ******************************** */

  $sel = mysqli_query($connect," SELECT count(*) as allcount from e_mart $searchQuery ");
  $records = mysqli_fetch_assoc($sel);
  $totalRecords = $records['allcount'];
  
  // $sel = mysqli_query($connect," SELECT count(*) as allcount from e_mart WHERE 1");
  // $records = mysqli_fetch_assoc($sel);
  // $totalRecordwithFilter = $records['allcount'];
  
  /* ******************************** */

  $result = mysqli_query($connect, $sqlQuery); //connect query with database
  
  $employeeData=array();
  
  while($row = mysqli_fetch_assoc($result)){ //fetch with the database in loop.
    $empRows = array();			
    $empRows[] =$row['id'];
    $empRows[] =ucfirst($row['first_3']);
    $empRows[] =$row['last_3'];
    $empRows[] =$row['company_3'];
    $empRows[] =$row['mail_3'];
    $empRows[] =$row['Phone_3'];
    $empRows[] = '<button type="button" name="update" id="'.$row["id"].'" class="btn btn-warning btn-xs update"> Update </button>';
    $empRows[] = '<button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete"> Delete </button>';
    $employeeData[] = $empRows;
    
    // print_r($employeeData);
    
  }
  $dataset = array(
    "recordsTotal"  	=>  $totalRecords,
    "recordsFiltered" 	=> 	$totalRecords,
    "data" => $employeeData,
    "sql" => $sqlQuery,
  );
  echo json_encode($dataset);//convert data into json.
}
?>
