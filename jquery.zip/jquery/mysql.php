<?php

$connect = mysqli_connect('localhost','root','inextrix','test_demo');

  if(isset($_POST["first_3"]) && isset($_POST['last_3']) && isset($_POST['company_3'])  && isset($_POST['add_line_1'])&& isset($_POST['add_line_2'])&& isset($_POST['city_3'])&& isset($_POST['state_3'])  && isset($_POST['pin_3']) && isset($_POST['Phone_3']) && isset($_POST['mail_3']))
    {
    // get values 
    $date = $_POST["date"];
    $pin = $_POST["pin_3"];
    $mail = $_POST["mail_3"];
    $city = $_POST["city_3"];
    $phone = $_POST["Phone_3"];
    $State = $_POST["state_3"];
    $lastname = $_POST["last_3"];
    $firstname = $_POST["first_3"];
    $address1 = $_POST["add_line_1"];
    $address2 = $_POST["add_line_2"];
    $companyname = $_POST["company_3"];
    
    $query = "INSERT INTO e_mart(date,first_3,last_3,company_3,add_line_1,add_line_2,city_3,state_3,pin_3,Phone_3,mail_3) VALUES('$date','$firstname','$lastname','$companyname','$address1','$address2','$city','$State ','$pin','$phone','$mail')";
    if (!$result = mysqli_query($connect, $query)) 
    {
      exit(mysqli_errors());
    }
    echo "1 Record Added!";
  }
    else {

      $draw = $_POST['draw'];
      $row = $_POST['start'];
      $rowperpage = $_POST['length']; // Rows display per page
      $columnIndex = $_POST['order'][0]['column']; // Column index
      $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
      $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
      $searchValue = mysqli_real_escape_string($connect,$_POST['search']['value']); // Search value
      
      /* Search */
      $searchQuery = " ";
      if($searchValue != ''){
        $searchQuery = " and (first_3 like '%".$searchValue."%' or company_3 like '%".$searchValue."%' or Phone_3 like'%".$searchValue."%' ) ";
      }
      
      $sel = mysqli_query($connect," SELECT count(*) as allcount from e_mart");
      $records = mysqli_fetch_assoc($sel);
      $totalRecords = $records['allcount'];
      
      $sel = mysqli_query($connect," SELECT count(*) as allcount from e_mart WHERE 1 $searchQuery");
      $records = mysqli_fetch_assoc($sel);
      $totalRecordwithFilter = $records['allcount'];
      
      $sql_table = " SELECT id, first_3, last_3,company_3,mail_3,Phone_3 from e_mart WHERE 1".$searchQuery."order by" ." $columnName $columnSortOrder  limit  $row,$rowperpage";
      // $sql_table = " SELECT id, first_3, last_3,company_3,mail_3,Phone_3 FROM e_mart ";
      $result = mysqli_query($connect, $sql_table);
      while($row = mysqli_fetch_assoc($result)){
        $dbdata[]= $row;
      }
      $dataset = array(
        // "iTotalRecords" => count($dbdata), 
        // "iTotalDisplayRecords" => $totalRecordwithFilter, 
        "iTotalRecords" => $totalRecords, 
        "iTotalDisplayRecords" => $totalRecordwithFilter, 
        "aaData" => $dbdata,
	      "sql" => $sql_table,
      );
      echo json_encode($dataset);
    }
?>