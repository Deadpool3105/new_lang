var $PinRegEx = /^[0-9]{6}$/;
var $ContactRegEx = /^[0-9\S]{10}$/;
var $NameRegEx = /^[a-zA-Z\s]{2,20}$/;
var $EmailRegEx = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

$(document).ready(function () {

    /* *************** First Name **************** */

    $("#first_3").blur(function () {
        $("#errorfname").empty();
        if ($(this).val() == "" || $(this).val() == null) {
            $("#errorfname").html(" *Please enter your firstname ");
        } else {
            if (!$(this).val().match($NameRegEx)) {
                $("#errorfname").html(" *Invalid First Name..! ");
            }
        }
    });
    $("#first_3").keypress(function () {

    })

    /* *************** Last Name **************** */

    $("#last_3").blur(function () {
        $("#errorlname").empty();
        if ($(this).val() == "" || $(this).val() == null) {
            $("#errorlname").html(" *Please enter your lastname.");
        } else {
            if (!$(this).val().match($NameRegEx)) {
                $("#errorlname").html(" *Invalid last name..! ");
            }
        }
    });
    $("#first_3").keypress(function () {

    })

    /* *************** Company Name **************** */

    $("#company_3").blur(function () {
        $("#errorcname").empty();
        if ($(this).val() == "" || $(this).val() == null) {
            $("#errorcname").html(" *Please enter companyname. ");
        } else {
            if (!$(this).val().match($NameRegEx)) {
                $("#errorcname").html(" *Invalid company name..! ");
            }
        }
    });
    $("#company_3").keypress(function () {

    });

    /* *************** Address **************** */


    $("#01").click(function () {
        if ($("#city_3").val() == "" || $("#city_3").val() == null) {
            $("#errorcity").html("*City name..!");
            return false;
        } else {
            $("#errorcity").empty();
        }
    });

    $("#01").click(function () {
        if ($("#state_3").val() == "" || $("#state_3").val() == null) {
            $("#errorstate").html("*State name..!");
            return false;
        } else {
            $("#errorstate").empty();
        }
    });

    $("#01").click(function () {
        if ($("#pin_3").val() == "" || $("#pin_3").val() == null) {
            $("#errorpin").html("*Pin code..!");
        } else {
            $("#errorpin").empty();
            if(!$("#pin_3").val().match($PinRegEx)) {
                $("#errorpin").html(" *Enter vaild pin..! ");
            }
        }
    });

    /* *************** Phone Number **************** */


    $("#Phone_3").blur(function () {
        $("#errorphone").empty();
        if ($(this).val() == "" || $(this).val() == null) {
            $("#errorphone").html("*Please enter Phone number.");
        } else {
            if (!$(this).val().match($ContactRegEx)) {
                $("#errorphone").html("*Enter vaild Numbers..! ");
            }
        }
    });

    /* *************** Mail **************** */

    $("#mail_3").blur(function () {
        $("#errormail").empty();
        if ($(this).val() == "" || $(this).val() == null) {
            $("#errormail").html("*Please enter Mail id.");
        } else {
            if (!$(this).val().match($EmailRegEx)) {
                $("#errormail").html("*Enter vaild Email id..! ");
            }
        }
    });

    $("#01").click(function () {

        if ($("#first_3").val() == "" || $("#last_3").val() == "" || $("#company_3").val() == "" || $("#Phone_3").val() == "" || $("mail_3").val() == "") {
            alert("pleace fill the details");
            return false;
        } else {
            $(this).hide();
            $.ajax({
                url: "ajax.html",
                type: "GET",
                async: false,
                success: function (res) {
                    $("#para").html(res)
                },
            });
        }
    });

});