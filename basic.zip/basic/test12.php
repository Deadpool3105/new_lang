<?php 

$fnameval = $_POST["fname"];
$mnameval = $_POST["mname"];
$lnameval = $_POST["lname"];
$addval = $_POST["add"];

echo "Hyy,<br>My name is: <b>$fnameval</b> <i>$mnameval</i> <u>$lnameval</u> <br> ";
echo "And my address is: <h1> $addval </h1>";

?>
