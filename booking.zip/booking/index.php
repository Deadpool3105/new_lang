<?php
// error_reporting(E_ALL);
// ini_set('display_errors', '1');

require_once ("Class/DBController.php");
require_once ("Class/Admin.php");
require_once ("Class/User.php");
require_once ("Class/Login.php");

$action = $_POST['action'];

if ($action == 'signup') {
    $your_name = $_POST['your_name'];
    $uname = $_POST['uname'];
    $mail = $_POST['mail'];
    $pwd = $_POST['pwd'];
    
    $obj = new Login();
    $insertId=$obj->addUSER($your_name,$uname,$mail,$pwd);

    echo 'Account created';
}else{
    require_once "view/signin.php";
}
?>