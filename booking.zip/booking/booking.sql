-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 03, 2023 at 11:18 AM
-- Server version: 10.1.48-MariaDB-0ubuntu0.18.04.1
-- PHP Version: 7.3.33-8+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `movie_details`
--

CREATE TABLE `movie_details` (
  `id` int(225) NOT NULL,
  `movie_name_id` int(225) NOT NULL,
  `movie_date` varchar(225) NOT NULL,
  `movie_start` varchar(225) NOT NULL,
  `movie_end` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `movie_details`
--

INSERT INTO `movie_details` (`id`, `movie_name_id`, `movie_date`, `movie_start`, `movie_end`) VALUES
(29, 107, '2023-01-01/2023-01-19', '15:00', '18:30'),
(30, 108, '2022-12-15/2022-12-29', '16:30', '19:35'),
(31, 109, '2022-12-24/2022-12-30', '16:30', '19:20'),
(32, 110, '2023-01-05/2023-01-20', '16:40', '19:30'),
(33, 111, '2022-12-26/2023-01-06', '19:32', '22:20');

-- --------------------------------------------------------

--
-- Table structure for table `movie_name`
--

CREATE TABLE `movie_name` (
  `id` int(11) NOT NULL,
  `movie_name` varchar(225) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `movie_name`
--

INSERT INTO `movie_name` (`id`, `movie_name`, `date_time`) VALUES
(107, 'once upon a time in mumbai', '2022-12-13 16:28:32'),
(108, 'pushpa', '2022-12-13 16:28:55'),
(109, 'Bhediya', '2022-12-23 16:30:47'),
(110, 'Now you see me 2', '2022-12-23 16:31:50'),
(111, 'K.G.F 2', '2022-12-23 16:32:32');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `your_name` varchar(225) NOT NULL,
  `user_name` varchar(225) NOT NULL,
  `email_id` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `your_name`, `user_name`, `email_id`, `password`, `date_time`) VALUES
(1, 'Vatsal', 'admin', 'admin@123.inextrix.coma', 'admin@123', '2022-12-02 11:43:59'),
(2, 'vatsal', 'deadpool', 'vatsal@675gmail.com', 'vatsal@123', '2022-12-02 12:27:29'),
(3, 'Ayush', 'pande', 'pandeayush@27gmail.com', 'ayush@123', '2022-12-02 12:43:45'),
(4, 'Ayush', 'mr.majnu', 'ankit@gmail.com', 'ayush@123', '2022-12-20 11:39:36'),
(5, 'bhanu pratap', 'bhanu', 'bhanupratap707@gmail.com', '123456zx', '2022-12-22 10:28:34');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `user_name` varchar(225) NOT NULL,
  `user_s_date` varchar(225) NOT NULL,
  `user_s_time` varchar(225) NOT NULL,
  `dateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `movie_id`, `user_name`, `user_s_date`, `user_s_time`, `dateTime`) VALUES
(4, 108, 'deadpool', '2022-12-17', '16:30-19:35', '2022-12-15 10:56:26'),
(12, 107, 'deadpool', '2022-12-24', '15:00-18:30', '2022-12-20 11:12:53'),
(14, 108, 'mr.majnu', '2022-12-22', '16:30-19:35', '2022-12-20 11:40:05'),
(15, 107, 'mr.majnu', '2022-12-23', '15:00-18:30', '2022-12-20 11:41:05'),
(17, 108, 'bhanu', '2022-12-24', '15:00-18:30', '2022-12-22 10:30:43'),
(18, 110, 'bhanu', '2022-12-31', '16:40-19:30', '2022-12-23 16:34:02'),
(19, 107, 'bhanu', '2022-12-24', '15:00-18:30', '2022-12-23 16:35:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `movie_details`
--
ALTER TABLE `movie_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movie_name`
--
ALTER TABLE `movie_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `movie_details`
--
ALTER TABLE `movie_details`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `movie_name`
--
ALTER TABLE `movie_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;
--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
