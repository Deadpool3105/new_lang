<?php
// error_reporting(E_ALL);
// ini_set('display_errors', '1');

require_once ("Class/DBController.php");

class Login{

    private $db_handle;
    
    function __construct() {
        $this->db_handle = new connection();    
    }

    function addUSER($yname,$uname,$mail,$password){
        $query = "INSERT INTO signup (your_name,user_name,email_id,password) VALUES(?,?,?,?)";
        $paramdata = [$yname,$uname,$mail,$password,];
        $insertId = $this->db_handle->insert($query,$paramdata);
        return $insertId;
    }
    

}
?>