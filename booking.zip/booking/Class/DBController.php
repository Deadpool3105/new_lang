<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

    class connection {
  
        private $host = 'localhost';
        private $user = 'admin';
        private $pwd = '=@!#254tecmint';
        private $dbName = 'movie-book';
        private $hdc = "mysql:host=localhost;dbname=movie-book";
        private $conn;
    
        function __construct(){
            $this->conn = new PDO($this->hdc,$this->user,$this->pwd);
            return $this->conn;
        }
        
        function insert($query,$paramdata) {
            $sql = $this->conn->prepare($query);
            $sql->execute($paramdata);
            return $insertId;
        }
        
    }


?>