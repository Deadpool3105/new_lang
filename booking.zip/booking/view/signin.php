<html>
<head>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="http://192.168.1.36/booking/view/css/style.css">
    <title>Log_In</title>
</head>
<body>
    <div class="d-flex justify-content-center">
        <div class="row fullBody mt-5">
            <div class="text-center mt-3">
                <h1 class="text-center mb-4">Login Form</h1>
            </div>
            <form id="SigninForm" class="ligfo mb-5">
                <div class="form-group mb-4">
                    <label for="userName" class="mb-2 h6">Username :</label>   
                    <div class="">
                        <input type="text" class="form-control mb-3" name="loginName" id="loginName" placeholder="x y z . . . .">
                    </div>
                    <p id="inncorectname" class="inncorectname"></p>
                </div>
                <div class="form-group">
                    <label for="userPassword" class="mb-2 h6">Password :</label>
                    <div class="">
                        <input type="password" class="form-control mb-3" name="loginPwd" id="loginPwd" placeholder="* * * * * * * * * ">
                    </div>
                    <p id="inncorectpwd" class="inncorectpwd"></p>
                </div>
                <div class="text-end"><a href="#">Forgot password ?</a></div>
                <div class="text-center mt-4">
                    <button type="submit" id="login" class="sub" name="login">Login</button>
                </div>
                <span id="inncLogin"></span>
                <center class="mt-3">
                    <p>Create a new account ? <a href="http://192.168.1.36/booking/view/signup.php">Signup</a></p>
                </center>
            </form>
        </div>
    </div>
</body>
<script src="http://192.168.1.36/booking/view/js/main.js" type="text/javascript"></script>
</html>