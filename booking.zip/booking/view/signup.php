<html>
<head>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="http://192.168.1.36/booking/view/css/style.css">
    <title>Sign Up</title>
</head>
<body>
    <div class="d-flex justify-content-center">
        <div class="row fullBody">
            <div class="text-center mt-2">
                <h1>Signup Form</h1>
            </div>
            <form id="accountOpen" class="sigfom mt-4">    
                <div class="form-group">
                    <div style="display: flex;justify-content: space-between;">
                        <label for="fullName" class="mb-2 h6" >Your Name :</label>
                    </div>
                    <input type="text" class="form-control" name="yourname" id="your_name" placeholder="x y z . . . .">
                </div>
                <div class="form-group">
                    <div style="display: flex;justify-content: space-between;">
                        <label for="userName" class="mb-2 mt-3 h6" >Username :</label>
                        <span id="check" class="mt-3">sd</span>
                    </div>
                    <input type="text" class="form-control " name="username" id="user_name" placeholder="x y z . . . .">
                </div>
                <div class="form-group">
                    <label for="userEmail" class="mb-2 mt-3 h6">Email :</label>
                    <input type="mail" class="form-control" name="useremail" id="user_email" placeholder="xyz@123gmail.com">
                </div>
                <div class="form-group">
                    <label for="userPassword" class="mb-2 mt-3 h6">Create Password :</label>
                    <input type="password" class="form-control" name="cpwd" id="cpwd" placeholder="Enter storng password . . . ">
                </div>
                <div class="form-group">
                    <label for="userPassword" class="mb-2 mt-3 h6">Confirm Password :</label>
                    <input type="password" class="form-control" name="user_password" id="user_password" placeholder="Same as above . . ">
                </div>
                <div class="text-center mt-4">
                    <button type="submit" class="sub" id="submit">Signup</button>
                </div>
                <center class="mt-3">
                    <p>Already have an account ? <a href="http://192.168.1.36/booking/view/signin.php">Login</a></p>
                </center>
            </form>
        </div>
    </div>
</body>
<script src="http://192.168.1.36/booking/view/js/main.js" type="text/javascript"></script>
</html>