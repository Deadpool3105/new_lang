$(document).ready(function(){
    /* ********************************** SIGNUP PAGE ********************************** */

  $("#accountOpen").validate({
    rules: {
      yourname:'required',
      username: "required",
      useremail:{
        required: true,
        email: true
      },
      cpwd:"required",
      user_password:{
        required:true,
        equalTo:"#cpwd"
      },
    },
    messages: {
      yourname:"Please enter your name !",
      username: "Please enter username !",
      useremail:{
        required:"Please enter email !",
        email:"Please enter valid email !"
      },
      cpwd:"Enter storng password !",
      user_password:{
        required:"Please enter password !",
        equalTo:"Same as above password !"
      }
    },
    submitHandler: function () {
      var your_name = $("#your_name").val().trim();
      var uname = $("#user_name").val().trim();
      var mail = $("#user_email").val();
      var pwd = $("#user_password").val();
      var action = "signup";
      $.ajax({
        url: "../index.php",
        method: "POST",
        data: {
          action: action,
          your_name:your_name,
          uname: uname,
          mail: mail,
          pwd: pwd,
        },
        success: function (data){
          alert(data);
        },
      });
    },
  });


  $("#").blur(function(){
    alert();
  })

})