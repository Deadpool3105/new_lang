$(document).ready(function () {
    $("#ticketTable").DataTable({
        // "processing": true,
        "order": [],
        "ajax": {
            url: "method.php",
            type: "POST",
            dataType: "json"
        },
        initComplete: function () {
            var input = $('.dataTables_filter input').unbind(),
                self = this.api(),
                $searchButton = $('#myInputTextField').click(function () {
                    self.search(input.val()).draw();
                });
            $('.dataTables_filter').append($searchButton);
        }
    });


    /* ******************************* DELETE DATA IN DATABASE ******************************* */

    $("#ticketTable").on('click', '.delete', function () {
        var empId = $(this).attr("id");
        var action = "ragiDelete";
        if (confirm("Are you sure ?")) {
            $.ajax({
                url: "method.php",
                method: "POST",
                data: { empId: empId, action: action },
                success: function (data) {
                    window.location.reload();
                }
            })
        } else {
            return false;
        }
    });

    /* ******************************* FETCH DATA IN UPDATE MODUAL ******************************* */

    $("#ticketTable").on('click', '.update', function () {
        var empId = $(this).attr("id");

        var action = 'fetRagister';
        $.ajax({
            url: 'method.php',
            method: "POST",
            data: { empId: empId, action: action },
            dataType: 'json',
            success: function (data) {
                // alert();
                // console.log(data);
                $('#employeeModal').modal('show');
                $('#empId').val(data.id);

                /* ***************************** FIRST BLOCK ***************************** */
                
                /* ************* CHECKBOX CHECKED IN DATATABLE ************* */
                var stclassval = data.start_class;                      // checkbox value from DB store in variable 
                var arr_stcls = stclassval.split(',');                  // split that data
                console.log("split val : " + arr_stcls);
                $('.upcheck').prop("checked", false);
                $.each(arr_stcls, function (key, value) {               // loop for DB values
                    console.log("val " + value);
                    $('.upcheck').each(function () {                    // loop for upadte checkbox values
                        console.log("chbx val : " + $(this).val() + " db val: " + value);
                        if (value == $(this).val()) {                   // check the value
                            $(this).prop("checked", true);
                        }
                    });
                });
                // $('#up_doctor').val(data.doctor);
                // $('.up_citizen').val(data.citizen);
                // $('.up_upgrade').val(data.upgrade);
                $('#up_TName').val(data.start_train);
                $('#up_SFrom').val(data.start_station_from);
                $('#up_Board').val(data.boarding);
                $('#up_gDate').val(data.start_date);
                $('#up_STo').val(data.start_station_to);
                $('#up_reservation').val(data.reservation);
                $('#up_berth').val(data.berth);

                /* ***************************** PERSON'S DETAILS ***************************** */

                $('#up_LU').val(data.choiceberth);
                $('#up_Meals').val(data.food);
                $('#up_Name').val(data.name);
                $('#up_Gender').val(data.gender);
                $('#up_Age').val(data.age);
                $('#up_Cname').val(data.childname);
                $('#up_Cgender').val(data.childgender_age);

                /* ***************************** SECOND BLOCK ***************************** */

                $('#up_rTName').val(data.return_train);
                $('#up_rDate').val(data.return_date);
                $('#up_rClass').val(data.return_class);
                $('#up_rSFrom').val(data.return_statio_from);
                $('#up_rSto').val(data.return_station_to);
                $('#up_applicant').val(data.applicant);
                $('#up_address').val(data.address);

            }
        })
        $(".done").click(function () {
            $('#employeeModal').modal('hide');
        })
    });

    /* ******************************* SAVE DATA IN DATABASE ******************************* */

    $(document).on('submit', '#employeeForm', function (e) {
        e.preventDefault();

        var empId = $('#empId').val();
        var action = 'updateRagister';
        var updateClass = [];
        var updateBerth = $("#up_berth").val();
        var updateLU = $("#up_LU").val();
        var updateMeals = $("#up_Meals").val();
        var updateName = $("#up_Name").val();
        var updateGender = $("#up_Gender").val();
        var updateAge = $("#up_Age").val();
        var updateCname = $("#up_Cname").val();
        var updateCgender = $("#up_Cgender").val();

        $(".upcheck").each(function () {
            if ($(this).is(":checked")) {
                updateClass.push($(this).val())
            }
        })
        updateClass = updateClass.toString();


        $('#save').attr('disabled', 'true');
        $.ajax({
            url: "method.php",
            method: "POST",
            data: {
                action: action,
                Id: empId,
                classUpdate: updateClass,
                berthUpdate: updateBerth,
                luUpdate: updateLU,
                mealsUpdate: updateMeals,
                nameUpdate: updateName,
                genderUpdate: updateGender,
                ageUpdate: updateAge,
                cNameUpdate: updateCname,
                cGenderUpdate: updateCgender,
            },
            success: function (data) {
                // $('#employeeForm')[0].reset();
                $('#employeeModal').modal('hide');
                $('#save').attr('disabled', false);
                // window.location.reload();
            }
        })
    });
})
