$(document).ready(function(){
    $("#ticketTable").DataTable({
        // "processing": true,
        "order": [],
        "ajax": {
            url: "method.php",
            type: "POST",
            // data: { action: 'listEmployee' },
            dataType: "json"
        },
        // "columnDefs": [
        //     { data: "j_id" },
        //     { data: "doctor" },
        //     { data: "citizen" },
        //     { data: "upgrade" },
        //     { data: "start_train" },
        //     { data: "start_date" },
        //     { data: "start_class" },
        //     { data: "berth" },
        //     { data: "return_train" },
        //     { data: "return_date" },
        //     { data: "return_class" },
        //     { data: "applicant" },
        //     { data: "name" },
        //     { data: "gender" },
        //     { data: "age" },
        // ],

        initComplete: function () {
            var input = $('.dataTables_filter input').unbind(),
                self = this.api(),
                $searchButton = $('#myInputTextField').click(function () {
                    self.search(input.val()).draw();
                });
            $('.dataTables_filter').append($searchButton);
        }
    });

    $("#ticketTable").on('click', '.delete', function () {
        var empId = $(this).attr("id");
        var action = "ragiDelete";
        if (confirm("Are you sure ?")) {
            $.ajax({
                url: "method.php",
                method: "POST",
                data: { empId: empId, action: action },
                success: function (data) {
                    alert(data)
                    // window.location.reload();
                }
            })
        } else {
            return false;
        }
    });
    
})