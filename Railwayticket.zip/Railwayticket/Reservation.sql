-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 03, 2023 at 11:19 AM
-- Server version: 10.1.48-MariaDB-0ubuntu0.18.04.1
-- PHP Version: 7.3.33-8+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Reservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `journey`
--

CREATE TABLE `journey` (
  `id` int(11) NOT NULL,
  `doctor` enum('No','Yes') NOT NULL,
  `citizen` enum('N','Y') NOT NULL,
  `upgrade` enum('Y','N') NOT NULL,
  `start_train` varchar(225) NOT NULL,
  `start_station_from` varchar(225) NOT NULL,
  `start_station_to` varchar(225) NOT NULL,
  `boarding` varchar(225) NOT NULL,
  `reservation` varchar(225) NOT NULL,
  `start_date` varchar(225) NOT NULL,
  `start_class` varchar(225) NOT NULL,
  `berth` varchar(225) NOT NULL,
  `return_train` varchar(225) NOT NULL,
  `return_date` varchar(225) NOT NULL,
  `return_class` varchar(225) NOT NULL,
  `return_statio_from` varchar(225) NOT NULL,
  `return_station_to` varchar(225) NOT NULL,
  `applicant` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `journey`
--

INSERT INTO `journey` (`id`, `doctor`, `citizen`, `upgrade`, `start_train`, `start_station_from`, `start_station_to`, `boarding`, `reservation`, `start_date`, `start_class`, `berth`, `return_train`, `return_date`, `return_class`, `return_statio_from`, `return_station_to`, `applicant`, `address`) VALUES
(11, 'Yes', 'Y', 'N', 'jhfdf', 'sddsf', 'sdfgfd', 'rtrty', 'gfjgh', '2022-11-17', 'FC', '6', 'dtg', '2022-11-24', 'SL', 'gtret', 'ertre', 'trytr', 'hxgdfh'),
(12, 'Yes', 'Y', 'N', 'jhfdf', 'sddsf', 'sdfgfd', 'rtrty', 'gfjgh', '2022-11-17', 'FC', '6', 'dtg', '2022-11-24', 'SL', 'gtret', 'ertre', 'trytr', 'hxgdfh'),
(13, 'Yes', 'Y', 'N', 'jhfdf', 'sddsf', 'sdfgfd', 'rtrty', 'gfjgh', '2022-11-17', 'FC', '6', 'dtg', '2022-11-24', 'SL', 'gtret', 'ertre', 'trytr', 'hxgdfh'),
(14, 'Yes', 'Y', 'N', 'jhfdf', 'sddsf', 'sdfgfd', 'rtrty', 'gfjgh', '2022-11-17', 'FC', '6', 'dtg', '2022-11-24', 'SL', 'gtret', 'ertre', 'trytr', 'hxgdfh'),
(15, 'Yes', 'Y', 'N', 'jhfdf', 'sddsf', 'sdfgfd', 'rtrty', 'gfjgh', '2022-11-17', 'FC', '6', 'dtg', '2022-11-24', 'SL', 'gtret', 'ertre', 'trytr', 'hxgdfh'),
(16, 'Yes', 'Y', 'N', 'jhfdf', 'sddsf', 'sdfgfd', 'rtrty', 'gfjgh', '2022-11-17', 'FC', '6', 'dtg', '2022-11-24', 'SL', 'gtret', 'ertre', 'trytr', 'hxgdfh'),
(17, 'Yes', 'Y', 'N', 'jhfdf', 'sddsf', 'sdfgfd', 'rtrty', 'gfjgh', '2022-11-17', 'FC', '6', 'dtg', '2022-11-24', 'SL', 'gtret', 'ertre', 'trytr', 'hxgdfh'),
(18, 'Yes', 'Y', 'N', 'jhfdf', 'sddsf', 'sdfgfd', 'rtrty', 'gfjgh', '2022-11-17', 'FC,CC', '3', 'dtg', '2022-11-24', 'SL', 'gtret', 'ertre', 'trytr', 'hxgdfh');

-- --------------------------------------------------------

--
-- Table structure for table `person_detail`
--

CREATE TABLE `person_detail` (
  `p_id` int(11) NOT NULL,
  `idofjourney` int(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `gender` varchar(225) NOT NULL,
  `age` int(11) NOT NULL,
  `travelauthorityno` varchar(225) NOT NULL,
  `choiceberth` varchar(225) NOT NULL,
  `food` varchar(225) NOT NULL,
  `childname` varchar(225) NOT NULL,
  `childgender_age` varchar(225) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `person_detail`
--

INSERT INTO `person_detail` (`p_id`, `idofjourney`, `name`, `gender`, `age`, `travelauthorityno`, `choiceberth`, `food`, `childname`, `childgender_age`, `date_time`) VALUES
(11, 11, 'ert', 'F', 45, '3563', 'UB', 'Veg.', '5', 'rrty', '2022-11-07 16:01:44'),
(12, 12, 'ert', 'F', 45, '3563', 'UB', 'Veg.', '5', 'rrty', '2022-11-07 16:01:46'),
(13, 13, 'ert', 'F', 45, '3563', 'UB', 'Veg.', '5', 'rrty', '2022-11-07 16:01:46'),
(14, 14, 'ert', 'F', 45, '3563', 'UB', 'Veg.', '5', 'rrty', '2022-11-07 16:01:47'),
(15, 15, 'ert', 'F', 45, '3563', 'UB', 'Veg.', '5', 'rrty', '2022-11-07 16:01:47'),
(16, 16, 'ert', 'F', 45, '3563', 'UB', 'Veg.', '5', 'rrty', '2022-11-07 16:01:47'),
(17, 17, 'ert', 'F', 45, '3563', 'UB', 'Veg.', '5', 'rrty', '2022-11-07 16:01:48'),
(18, 18, 'ert', 'F', 45, '3563', 'UB', 'Veg.', '5', 'rrty', '2022-11-07 16:01:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `journey`
--
ALTER TABLE `journey`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `person_detail`
--
ALTER TABLE `person_detail`
  ADD PRIMARY KEY (`p_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `journey`
--
ALTER TABLE `journey`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `person_detail`
--
ALTER TABLE `person_detail`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
