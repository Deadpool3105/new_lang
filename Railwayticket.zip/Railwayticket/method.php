<?php

/* ******************************* CONNECTION ******************************* */

$connect = mysqli_connect('localhost','root','inextrix','Reservation'); 

/* ******************************* VARIABLES ******************************* */

/* **************** FRIST BLOCK **************** */
 
$dr = $_POST['doctor'];
$citizen = $_POST['citizen'];
$upgraded = $_POST['upgrade'];
$goingTrainName = $_POST['startTrain'];
$goingDate = $_POST['startDate'];
$goingStationFrom = $_POST['startSfrom'];
$goingStationTo = $_POST['startSto'];
$boarding = $_POST['startBoarding'];
$reservation = $_POST['startReservation'];
$startClass = $_POST['startClass'];
$berth = $_POST['startBerth'];

/* **************** PERSON'S DETAILS **************** */

$namePtext = $_POST['nameP'];
$pGender = $_POST['genderP'];
$agePtext = $_POST['ageP'];
$travel = $_POST['Travel'];
$selecLUbterth = $_POST['berthLU'];
$selectVNmeals = $_POST['mealsVN'];
$childName = $_POST['nameChild'];
$childGender = $_POST['genderChild'];


/* **************** SECOND BLOCK **************** */

$returnTrainName = $_POST['returnTrain'];
$returnDate = $_POST['returnDate'];
$returnClass = $_POST['returnClass'];
$returnStationFrom = $_POST['returnSfrom'];
$returnStationto = $_POST['returnSto'];
$applicant = $_POST['returnApplicant'];
$address = $_POST['returnAddress'];
// $signature = $_POST['signature'];
// $telephoneNumber = $_POST['telephoneNumber'];
// $timeDate = $_POST['timeDate'];

/* ******************************* INSERT DATA IN DATABASE ******************************* */

// print_r($_POST);
// exit();
// if($_POST['action'] == "ragiDelete"){
//   $emp_id = $_POST['empId'];
//   $jsqlDelete = "DELETE FROM journey WHERE id = $emp_id";
//   mysqli_query($connect,$jsqlDelete); 
  
// }
//  else if ($_POST['action'] == 'ragiTicket') {
  
//   /* ******************************* INSERT TRAIN DATA IN DATABASE ******************************* */
  
//   $query = "INSERT INTO journey(doctor,citizen,upgrade,start_train,start_date,start_station_from,start_station_to,boarding,reservation,start_class,berth, return_train, return_date,return_class,return_statio_from, return_station_to, applicant,address) VALUES('$dr','$citizen','$upgraded','$goingTrainName','$goingDate','$goingStationFrom','$goingStationTo','$boarding','$reservation','$startClass','$berth','$returnTrainName','$returnDate','$returnClass','$returnStationFrom','$returnStationto','$applicant','$address')";
//   $output = mysqli_query($connect, $query);
  
  
//   $id = mysqli_insert_id($connect);
  
//   /* ******************************* INSERT PERSON'S DATA IN DATABASE ******************************* */
  
//   $prquery = "INSERT INTO person_detail(idofjourny,name,gender,age,travelauthorityno,choiceberth,food,childname,childgender_age) VALUES('$id','$namePtext','$pGender','$agePtext','$travel','$selecLUbterth','$selectVNmeals','$childName','$childGender')";
//   $prOutput = mysqli_query($connect,$prquery);
  
//   echo"1 Record Aedded!";
// }
// else{

//   $rowstart = $_POST['start'];
//   $rowperpage = $_POST['length']; // Rows display per page
//   $columnIndex = $_POST['order'][0]['column']+1; // Column index
//   $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
//   $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
//   $searchValue = mysqli_real_escape_string($connect,$_POST['search']['value']); // Search value
  
//   /* ******************************* */

//   $jsql = "SELECT id,doctor,citizen,upgrade,start_train,start_date,start_class,berth,return_train,return_date,return_class,applicant FROM journey";

//   $result = mysqli_query($connect, $jsql); //connect query with database
  
//   $employeeData=array();
  
//   while($row = mysqli_fetch_assoc($result)){ //fetch with the database in loop.
//     $empRows = array();			
//     $empRows[] =$row['id'];
//     $empRows[] =$row['doctor'];
//     $empRows[] =$row['citizen'];
//     $empRows[] =$row['upgrade'];
//     $empRows[] =$row['start_train'];
//     $empRows[] =$row['start_date'];
//     $empRows[] =$row['start_class'];
//     $empRows[] =$row['berth'];
//     $empRows[] =$row['return_train'];
//     $empRows[] =$row['return_date'];
//     $empRows[] =$row['return_class'];
//     $empRows[] =$row['applicant'];
//     $empRows[] = '<button type="button" name="update" id="'.$row["id"].'" class="btn btn-warning btn-xs update"> Update </button>';
//     $empRows[] = '<button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete"> Delete </button>';
//     $employeeData[] = $empRows;
    
//     // print_r($employeeData);
    
//   }
//   $dataset = array(
//     "recordsTotal"  	=>  $totalRecords,
//     "recordsFiltered" 	=> 	$totalRecords,
//     "data" => $employeeData,
//     "sql" => $jsql,
//   );
//   echo json_encode($dataset);//convert data into json.
// }



if($_POST['action'] == "ragiDelete"){
  $emp_id = $_POST['empId'];
  $jsqlDelete = "DELETE FROM person_detail WHERE id = $emp_id";
  mysqli_query($connect,$jsqlDelete); 
  
}

else if ($_POST['action'] == 'ragiTicket') {
  
  /* ******************************* INSERT TRAIN DATA IN DATABASE ******************************* */
  
  $query = "INSERT INTO journey (doctor,citizen,upgrade,start_train,start_date,start_station_from,start_station_to,boarding,reservation,start_class,berth, return_train, return_date,return_class,return_statio_from, return_station_to, applicant,address) VALUES('$dr','$citizen','$upgraded','$goingTrainName','$goingDate','$goingStationFrom','$goingStationTo','$boarding','$reservation','$startClass','$berth','$returnTrainName','$returnDate','$returnClass','$returnStationFrom','$returnStationto','$applicant','$address')";
  $output = mysqli_query($connect, $query);
  
  
  $id = mysqli_insert_id($connect);
  
  /* ******************************* INSERT PERSON'S DATA IN DATABASE ******************************* */
  
  $prquery = "INSERT INTO person_detail(idofjourny,name,gender,age,travelauthorityno,choiceberth,food,childname,childgender_age) VALUES('$id','$namePtext','$pGender','$agePtext','$travel','$selecLUbterth','$selectVNmeals','$childName','$childGender')";
  $prOutput = mysqli_query($connect,$prquery);
  
  echo"1 Record Aedded!";
}
else{

  $rowstart = $_POST['start'];
  $rowperpage = $_POST['length']; // Rows display per page
  $columnIndex = $_POST['order'][0]['column']+1; // Column index
  $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
  $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
  $searchValue = mysqli_real_escape_string($connect,$_POST['search']['value']); // Search value
  
  /* ******************************* */

  $jsql = "SELECT journey.id,journey.doctor,journey.citizen,journey.upgrade,journey.start_train,journey.start_date,journey.start_class,journey.berth,journey.return_train,journey.return_date,journey.return_class,journey.applicant,person_detail.id,person_detail.name,person_detail.gender,person_detail.age from journey inner join person_detail on journey.id = person_detail.id ";

  $result = mysqli_query($connect, $jsql); //connect query with database
  
  $employeeData=array();
  
  while($row = mysqli_fetch_assoc($result)){ //fetch with the database in loop.
    $empRows = array();			
    $empRows[] =$row['id'];
    $empRows[] =$row['doctor'];
    $empRows[] =$row['citizen'];
    $empRows[] =$row['upgrade'];
    $empRows[] =$row['start_train'];
    $empRows[] =$row['start_date'];
    $empRows[] =$row['start_class'];
    $empRows[] =$row['berth'];
    $empRows[] =$row['return_train'];
    $empRows[] =$row['return_date'];
    $empRows[] =$row['return_class'];
    $empRows[] =$row['applicant'];
    $empRows[] =$row['name'];
    $empRows[] =$row['gender'];
    $empRows[] =$row['age'];
    $empRows[] = '<button type="button" name="update" id="'.$row["id"].'" class="btn btn-warning btn-xs update"> Update </button>';
    $empRows[] = '<button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete"> Delete </button>';
    $employeeData[] = $empRows;
    
    // print_r($employeeData);
    
  }
  $dataset = array(
    "recordsTotal"  	=>  $totalRecords,
    "recordsFiltered" 	=> 	$totalRecords,
    "data" => $employeeData,
    // "sql" => $jsql,
  );
  echo json_encode($dataset);//convert data into json.
} 
?>
