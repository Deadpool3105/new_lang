<?php

/* ******************************* CONNECTION ******************************* */

$connect = mysqli_connect('localhost','root','inextrix','Reservation'); 

/* ******************************* VARIABLES ******************************* */

/* **************** FRIST BLOCK **************** */
 
$dr = $_POST['doctor'];
$citizen = $_POST['citizen'];
$upgraded = $_POST['upgrade'];
$goingTrainName = $_POST['startTrain'];
$goingDate = $_POST['startDate'];
$goingStationFrom = $_POST['startSfrom'];
$goingStationTo = $_POST['startSto'];
$boarding = $_POST['startBoarding'];
$reservation = $_POST['startReservation'];
$startClass = $_POST['startClass'];
$berth = $_POST['startBerth'];

/* **************** PERSON'S DETAILS **************** */

$namePtext = $_POST['nameP'];
$pGender = $_POST['genderP'];
$agePtext = $_POST['ageP'];
$travel = $_POST['Travel'];
$selecLUbterth = $_POST['berthLU'];
$selectVNmeals = $_POST['mealsVN'];
$childName = $_POST['nameChild'];
$childGender = $_POST['genderChild'];


/* **************** SECOND BLOCK **************** */

$returnTrainName = $_POST['returnTrain'];
$returnDate = $_POST['returnDate'];
$returnClass = $_POST['returnClass'];
$returnStationFrom = $_POST['returnSfrom'];
$returnStationto = $_POST['returnSto'];
$applicant = $_POST['returnApplicant'];
$address = $_POST['returnAddress'];
// $signature = $_POST['signature'];
// $telephoneNumber = $_POST['telephoneNumber'];
// $timeDate = $_POST['timeDate'];

// print_r($_POST);
// exit();


if ($_POST['action'] == 'fetRagister') {
  $emp_id = $_POST['empId'];
  
  // echo $sqlQueryF = "SELECT * FROM journey WHERE id = $emp_id ";
  $sqlQueryF = "SELECT * FROM journey INNER JOIN person_detail WHERE journey.id = $emp_id AND person_detail.idofjourney = $emp_id";
  $result = mysqli_query($connect,$sqlQueryF);
  $up_row = mysqli_fetch_assoc($result);
  echo json_encode($up_row);
}

elseif ($_POST['action'] == 'updateRagister') {
 $emp_id = $_POST["Id"];
 echo $query1Update = "UPDATE journey SET start_class='".$_POST['classUpdate']."', berth='".$_POST['berthUpdate']."' WHERE id = '$emp_id'  ";
 echo $query2Update = "UPDATE person_detail SET name= '".$_POST['nameUpdate']."', gender='".$_POST['genderUpdate']."', age='".$_POST['ageUpdate']."', choiceberth= '".$_POST['luUpdate']."',food= '".$_POST['mealsUpdate']."',childname='".$_POST['cNameUpdate']."',childgender_age='".$_POST['cGenderUpdate']."' WHERE idofjourney = '$emp_id' ";

  $result = mysqli_query($connect,$query1Update);
  $result = mysqli_query($connect,$query2Update);
  
}

elseif($_POST['action'] == "ragiDelete"){
  $emp_id = $_POST['empId'];
  $jsqlDelete = "DELETE FROM journey WHERE id = $emp_id";
  $j2sqlDelete = "DELETE FROM person_detail WHERE idofjourney = $emp_id";
  mysqli_query($connect,$jsqlDelete); 
  mysqli_query($connect,$j2sqlDelete); 
  
}

elseif ($_POST['action'] == 'ragiTicket') {
  
  /* ******************************* INSERT TRAIN DATA IN DATABASE ******************************* */
  
  $query = "INSERT INTO journey (doctor,citizen,upgrade,start_train,start_date,start_station_from,start_station_to,boarding,reservation,start_class,berth, return_train, return_date,return_class,return_statio_from, return_station_to, applicant,address) VALUES('$dr','$citizen','$upgraded','$goingTrainName','$goingDate','$goingStationFrom','$goingStationTo','$boarding','$reservation','$startClass','$berth','$returnTrainName','$returnDate','$returnClass','$returnStationFrom','$returnStationto','$applicant','$address')";
  $output = mysqli_query($connect, $query);
  
  
  $id = mysqli_insert_id($connect);
  
  /* ******************************* INSERT PERSON'S DATA IN DATABASE ******************************* */
  
  $prquery = "INSERT INTO person_detail(idofjourney,name,gender,age,travelauthorityno,choiceberth,food,childname,childgender_age) VALUES('$id','$namePtext','$pGender','$agePtext','$travel','$selecLUbterth','$selectVNmeals','$childName','$childGender')";
  $prOutput = mysqli_query($connect,$prquery);
  
  echo"1 Record Aedded!";
}
else{

  $rowstart = $_POST['start'];
  $rowperpage = $_POST['length']; // Rows display per page
  $columnIndex = $_POST['order'][0]['column']+1; // Column index
  $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
  $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
  $searchValue = mysqli_real_escape_string($connect,$_POST['search']['value']); // Search value
  
  /* ******************************* SHOW DATA IN DATATABLE ******************************* */

  $jsql = "SELECT journey.id,journey.doctor,journey.citizen,journey.upgrade,journey.start_train,journey.start_station_from,journey.start_station_to,journey.boarding,journey.reservation,journey.start_date,journey.start_class,journey.berth,journey.return_train,journey.return_date,journey.return_class,journey.return_statio_from,journey.return_station_to,journey.applicant,person_detail.p_id,person_detail.name,person_detail.gender,person_detail.age,person_detail.travelauthorityno,person_detail.choiceberth,person_detail.food,person_detail.childname,person_detail.childgender_age from journey inner join person_detail on journey.id = person_detail.idofjourney ";

  $result = mysqli_query($connect, $jsql); //connect query with database
  
  $employeeData=array();
  
  while($row = mysqli_fetch_assoc($result)){ //fetch with the database in loop.
    $empRows = array();			

    /* **************** FRIST BLOCK **************** */

    $empRows[] =$row['id'];
    // $empRows[] =$row['doctor'];
    // $empRows[] =$row['citizen'];
    // $empRows[] =$row['upgrade'];
    $empRows[] =$row['start_train'];
    // $empRows[] =$row['start_date'];
    // $empRows[] =$row['start_station_from'];
    // $empRows[] =$row['start_station_to'];
    // $empRows[] =$row['boarding'];
    // $empRows[] =$row['reservation'];
    $empRows[] =$row['start_class'];
    $empRows[] =$row['berth'];
    
    /* **************** SECOND BLOCK **************** */
    
    // $empRows[] =$row['p_id'];
    $empRows[] =$row['name'];
    $empRows[] =$row['gender'];
    $empRows[] =$row['age'];
    // $empRows[] =$row['travelauthorityno'];
    $empRows[] =$row['choiceberth'];
    $empRows[] =$row['food'];
    $empRows[] =$row['childname'];
    $empRows[] =$row['childgender_age'];

    /* **************** SECOND BLOCK **************** */
    
    $empRows[] =$row['return_train'];
    // $empRows[] =$row['return_date'];
    $empRows[] =$row['return_class'];
    // $empRows[] =$row['return_statio_from'];
    // $empRows[] =$row['return_station_to'];
    $empRows[] =$row['applicant'];
    $empRows[] = '<button type="button" name="update" id="'.$row["id"].'" class="btn btn-warning btn-xs update"> Update </button>';
    $empRows[] = '<button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete"> Delete </button>';
    $employeeData[] = $empRows;
    
    // print_r($employeeData);
    
  }
  $dataset = array(
    // "recordsTotal"  	=>  $totalRecords,
    // "recordsFiltered" 	=> 	$totalRecords,
    "data" => $employeeData,
    // "sql" => $jsql,
  );
  echo json_encode($dataset);//convert data into json.
} 
?>
