$(document).ready(function () {
    
    $("#reservation").validate({
        rules: {
            goingTrainName: {
                required: true,
            },
        },
        messages: {
            goingTrainName: {
                required: "*Pleace a enter train name!",
            },
        },

        /* ***************************** STORE DATA IN DATABASE ***************************** */

        submitHandler: function () {
            
            /* **************** FRIST BLOCK **************** */

            var doctor;
            var citizen;
            var upgrade;
            var startTrain = $("#goingTrainName").val();
            var startDate = $("#goingDate").val();
            var startSfrom = $("#goingStationFrom").val();
            var startSto = $("#goingStationTo").val();
            var boarding = $("#boarding").val();
            var reservation = $("#goingReservation").val();
            var startClass = [];
            var berth = $("#berth").val();
            
            /* ************** PERSON'S DETAIL ************** */

            var pName = $("#nameText1").val();
            var pGender = $("#selectGender1").val();
            var pAge = $("#ageText1").val();
            var travel = $("#travelText1").val();
            var luBerth = $("#selectBerth1").val();
            var vnMeals = $("#selectMeals1").val();
            var childname = $("#nameChildren1").val();
            var childGender = $("#childrenGender").val();


            /* *************** SECOND BLOCK **************** */
            
            var returnTrain = $("#returnTrainName").val();
            var returnDate = $("#returnDate").val();
            var returnClass = $("#returnClass").val();
            var returnSfrom = $("#returnStationFrom").val();
            var returnSto = $("#returnStationto").val();
            var applicant = $("#applicant").val();
            var address = $("#address").val();

            var action = 'ragiTicket';

            $("#doctor").filter(function () {
                if ($(this).is(":checked")) {
                    doctor = $(this).val();
                }
            })

            $(".fristRadio").each(function () {
                if ($(this).is(":checked")) {
                    citizen = $(this).val();
                }
            })
            $(".secondRadio").each(function () {
                if ($(this).is(":checked")) {
                    upgrade = $(this).val();
                }
            })
            $(".clcheck").each(function () {
                if ($(this).is(":checked")) {
                    startClass.push($(this).val());
                }
            })
            startClass = startClass.toString();

            $.ajax({
                url: "method.php",
                method: "POST",
                data: {
                    doctor: doctor,
                    citizen: citizen,
                    upgrade: upgrade,
                    startTrain: startTrain,
                    startDate: startDate,
                    startSfrom: startSfrom,
                    startSto: startSto,
                    startBoarding: boarding,
                    startReservation: reservation,
                    startClass: startClass,
                    startBerth: berth,

                    nameP:pName,
                    genderP:pGender,
                    ageP:pAge,
                    Travel:travel,
                    berthLU:luBerth,
                    mealsVN:vnMeals,
                    nameChild:childname,
                    genderChild:childGender,

                    returnTrain: returnTrain,
                    returnDate: returnDate,
                    returnClass: returnClass,
                    returnSfrom: returnSfrom,
                    returnSto: returnSto,
                    returnApplicant: applicant,
                    returnAddress: address,
                    action:action,

                },
                success: function (data) {
                    alert(data)
                }
            });
        }
    });
    
    /* ************************* BUTTON DISABLE ************************* */

    $("#cnf").attr('disabled', true);
    $("#ckbox").click(function () {
        $("#cnf").attr('disabled', false);
    });

})