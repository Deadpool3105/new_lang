<?php

include 'function.php';

if ($_POST['action'] == 'signUp') {
    userSignup();
}
elseif ($_POST['action'] == 'login'){
    user_login();
}
elseif($_POST['action'] == 'movie_add'){
    movie_add();
}
elseif ($_POST['action'] == 'user_ragister_data') {
    user_ragister_data();
}
elseif ($_POST['action'] == 'update_movie') {
    update_movie();
}
elseif ($_POST['action'] == 'delete_movie') {
    deleteMovie();
}
elseif ($_POST['action'] == 'user_select_movie') {
    user_select_movie();
}
elseif ($_POST['action'] == 'date_range_check') {
    date_availbility();
}
elseif ($_POST['action'] == 'user_book') {
    user_ticket();
}
else{
    show_edit_data();
}

?>